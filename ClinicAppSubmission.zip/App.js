import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, TextInput, Button, ScrollView, Switch, StyleSheet } from 'react-native';

const Tab = createBottomTabNavigator();

function BiodataScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.label}>First Name:</Text>
      <TextInput style={styles.input} />
      
      <Text style={styles.label}>Surname:</Text>
      <TextInput style={styles.input} />
      
      <Text style={styles.label}>Middle Name:</Text>
      <TextInput style={styles.input} />
      
      <Text style={styles.label}>Date of Birth:</Text>
      <TextInput style={styles.input} />
      
      <Text style={styles.label}>Home Address:</Text>
      <TextInput style={styles.input} />
      
      <Text style={styles.label}>Date of Registration:</Text>
      <TextInput style={styles.input} />
      
      <Text style={styles.label}>Receive Notifications:</Text>
      <Switch />
      
      <Button title="Save" onPress={() => {}} />
    </ScrollView>
  );
}

function ClinicalRecordsScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.label}>Clinic Date:</Text>
      <TextInput style={styles.input} />
      
      <Text style={styles.label}>Nature of Ailment:</Text>
      <TextInput style={styles.input} />
      
      <Text style={styles.label}>Medicine Prescribed:</Text>
      <TextInput style={styles.input} />
      
      <Text style={styles.label}>Procedure Undertaken:</Text>
      <TextInput style={styles.input} />
      
      <Text style={styles.label}>Date of Next Appointment:</Text>
      <TextInput style={styles.input} />
      
      <Button title="Save" onPress={() => {}} />
    </ScrollView>
  );
}

function MyTabs() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Biodata" component={BiodataScreen} />
      <Tab.Screen name="Clinical Records" component={ClinicalRecordsScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <MyTabs />
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: 'yellow',
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 8,
    marginBottom: 20,
    backgroundColor: '#fff',
  },
});