import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import BiodataScreen from './screens/BiodataScreen';
import ClinicVisitationScreen from './screens/ClinicVisitationScreen';

const Tab = createBottomTabNavigator();

const Navigation = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Biodata" component={BiodataScreen} />
        <Tab.Screen name="Clinic Visitation" component={ClinicVisitationScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default Navigation;