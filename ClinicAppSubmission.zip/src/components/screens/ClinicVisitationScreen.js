import React from 'react';
import { View, Text, TextInput, StyleSheet, ScrollView } from 'react-native';

const ClinicVisitationScreen = () => {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.label}>Date of Visit</Text>
      <TextInput style={styles.input} />

      <Text style={styles.label}>Diagnosis</Text>
      <TextInput style={styles.input} />

      <Text style={styles.label}>Treatment</Text>
      <TextInput style={styles.input} />

      <Text style={styles.label}>Doctor's Notes</Text>
      <TextInput style={styles.input} multiline numberOfLines={4} />

      <Text style={styles.label}>Next Appointment</Text>
      <TextInput style={styles.input} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFE0',
    padding: 16,
  },
  label: {
    fontSize: 18,
    color: '#333',
    marginTop: 16,
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    padding: 8,
    marginTop: 8,
    backgroundColor: '#fff',
  },
});

export default ClinicVisitationScreen;