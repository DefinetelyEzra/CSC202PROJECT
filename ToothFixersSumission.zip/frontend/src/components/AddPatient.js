// components/AddPatient.js
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function AddPatient({ fetchPatients }) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();

    const newPatient = { firstName, lastName };

    try {
      await axios.post('http://localhost:5000/api/patients', newPatient);
      fetchPatients(); // Refresh the patient list
      navigate('/'); // Redirect to the home page
    } catch (error) {
      console.error('Failed to add patient', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        First Name:
        <input
          type="text"
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
          required
        />
      </label>
      <br />
      <label>
        Last Name:
        <input
          type="text"
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
          required
        />
      </label>
      <br />
      <button type="submit">Add Patient</button>
    </form>
  );
}

export default AddPatient;