// components/PatientList.js
import React from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function PatientList({ patients, setPatients }) {
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/patients/${id}`);
      setPatients(patients.filter(patient => patient.id !== id));
    } catch (error) {
      console.error('Failed to delete patient', error);
    }
  };

  return (
    <div>
      <h2>Patient List</h2>
      <ul>
        {patients.map(patient => (
          <li key={patient.id}>
            {patient.firstName} {patient.lastName}
            <button onClick={() => handleDelete(patient.id)}>Delete</button>
            <Link to={`/edit/${patient.id}`}>Edit</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default PatientList;