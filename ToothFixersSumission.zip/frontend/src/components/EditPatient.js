// components/EditPatient.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

function EditPatient({ fetchPatients }) {
  const [patient, setPatient] = useState({ firstName: '', lastName: '' });
  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPatient = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/patients/${id}`);
        setPatient(response.data);
      } catch (error) {
        console.error('Failed to fetch patient', error);
      }
    };

    fetchPatient();
  }, [id]);

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      await axios.put(`http://localhost:5000/api/patients/${id}`, patient);
      fetchPatients();
      navigate('/');
    } catch (error) {
      console.error('Failed to update patient', error);
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setPatient({ ...patient, [name]: value });
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        First Name:
        <input
          type="text"
          name="firstName"
          value={patient.firstName}
          onChange={handleChange}
          required
        />
      </label>
      <br />
      <label>
        Last Name:
        <input
          type="text"
          name="lastName"
          value={patient.lastName}
          onChange={handleChange}
          required
        />
      </label>
      <br />
      <button type="submit">Update Patient</button>
    </form>
  );
}

export default EditPatient;