// config/db.js
const { Pool } = require('pg');

const pool = new Pool({
    user: 'postgres',          
    host: 'localhost',
    database: 'toothfixers',   
    password: 'HousesobigHeartsosmall.',  
    port: 5432                 
});

pool.connect()
    .then(() => console.log('PostgreSQL connected...'))
    .catch(err => console.error('PostgreSQL connection error', err.stack));

module.exports = pool;
