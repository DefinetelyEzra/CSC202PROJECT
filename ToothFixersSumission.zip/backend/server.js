// server.js

const express = require('express');
const bodyParser = require('body-parser');
const pool = require('./config/db');
const cors = require('cors');

const app = express();
const port = 5000;

app.use(cors());
app.use(bodyParser.json());

// Routes for managing patients (Biodata)
app.post('/api/patients', (req, res) => {
    const { firstname, middlename, surname, dateofbirth, homeaddress, dateofregistration, _22120613109 } = req.body;
    const query = 'INSERT INTO Biodata (firstname, middlename, surname, dateofbirth, homeaddress, dateofregistration, _22120613109) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *';
    const values = [firstname, middlename, surname, dateofbirth, homeaddress, dateofregistration, _22120613109];
    
    pool.query(query, values)
        .then(result => res.json(result.rows[0]))
        .catch(err => res.status(500).send(err));
});

app.get('/api/patients', (req, res) => {
    pool.query('SELECT * FROM Biodata')
        .then(result => res.json(result.rows))
        .catch(err => res.status(500).send(err));
});

app.get('/api/patients/:id', (req, res) => {
    const id = req.params.id;
    pool.query('SELECT * FROM Biodata WHERE patientid = $1', [id])
        .then(result => res.json(result.rows[0]))
        .catch(err => res.status(500).send(err));
});

app.put('/api/patients/:id', (req, res) => {
    const id = req.params.id;
    const { firstname, middlename, surname, dateofbirth, homeaddress, dateofregistration, _22120613109 } = req.body;
    const query = 'UPDATE Biodata SET firstname = $1, middlename = $2, surname = $3, dateofbirth = $4, homeaddress = $5, dateofregistration = $6, _22120613109 = $7 WHERE patientid = $8 RETURNING *';
    const values = [firstname, middlename, surname, dateofbirth, homeaddress, dateofregistration, _22120613109, id];
    
    pool.query(query, values)
        .then(result => res.json(result.rows[0]))
        .catch(err => res.status(500).send(err));
});

app.delete('/api/patients/:id', (req, res) => {
    const id = req.params.id;
    pool.query('DELETE FROM Biodata WHERE patientid = $1', [id])
        .then(() => res.send(`Patient with ID ${id} deleted.`))
        .catch(err => res.status(500).send(err));
});

// Routes for managing clinical records
app.post('/api/clinical_records', (req, res) => {
    const { patientid, clinicdate, natureofailment, medicineprescribed, procedure_undertaken, dateofnextappointment } = req.body;
    const query = 'INSERT INTO ClinicalRecord (patientid, clinicdate, natureofailment, medicineprescribed, procedure_undertaken, dateofnextappointment) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *';
    const values = [patientid, clinicdate, natureofailment, medicineprescribed, procedure_undertaken, dateofnextappointment];
    
    pool.query(query, values)
        .then(result => res.json(result.rows[0]))
        .catch(err => res.status(500).send(err));
});

app.get('/api/clinical_records', (req, res) => {
    pool.query('SELECT * FROM ClinicalRecord')
        .then(result => res.json(result.rows))
        .catch(err => res.status(500).send(err));
});

app.get('/api/clinical_records/:id', (req, res) => {
    const id = req.params.id;
    pool.query('SELECT * FROM ClinicalRecord WHERE recordid = $1', [id])
        .then(result => res.json(result.rows[0]))
        .catch(err => res.status(500).send(err));
});

app.put('/api/clinical_records/:id', (req, res) => {
    const id = req.params.id;
    const { patientid, clinicdate, natureofailment, medicineprescribed, procedure_undertaken, dateofnextappointment } = req.body;
    const query = 'UPDATE ClinicalRecord SET patientid = $1, clinicdate = $2, natureofailment = $3, medicineprescribed = $4, procedure_undertaken = $5, dateofnextappointment = $6 WHERE recordid = $7 RETURNING *';
    const values = [patientid, clinicdate, natureofailment, medicineprescribed, procedure_undertaken, dateofnextappointment, id];
    
    pool.query(query, values)
        .then(result => res.json(result.rows[0]))
        .catch(err => res.status(500).send(err));
});

app.delete('/api/clinical_records/:id', (req, res) => {
    const id = req.params.id;
    pool.query('DELETE FROM ClinicalRecord WHERE recordid = $1', [id])
        .then(() => res.send(`Clinical record with ID ${id} deleted.`))
        .catch(err => res.status(500).send(err));
});

// Start server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});